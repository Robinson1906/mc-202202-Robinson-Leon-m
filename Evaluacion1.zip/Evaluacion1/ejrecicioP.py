



from inspect import isasyncgenfunction


def tryInt(txt:str):#metodo para leer datos enteros
    isTry=True
    while isTry:
        try:
            x=int(input(txt))
        except:
            print("No es valido, ingrese nuevamente el dato")
            
        else:
            isTry=False
            return x


def union(a,b):
        unionC=set()

        for i in b:
 
            unionC.add(i)
        for i in a:

            unionC.add(i)
        
        return unionC

def interseccion(a,b):
    inter=set()

    for i in a:
        if i in b:
            inter.add(i)
    return inter

def dif(a,b):
    inter=set()

    for i in a:
        if not(i in b):

            inter.add(i)
    return inter

def simetrica(a,b):
    sim=set()

    union=set()

    for i in a:

        union.add(i)
    for i in b:

        union.add(i)
    
    inter=set()

    for i in a:
        if i in b:
            inter.add(i)
    
    for i in union:
        if not(i in inter):

            sim.add(i)
    return sim



# M={1,2,3,4}
# L={4,5,6,7}
a={10,11,12,13,14,15,16,17}
b={0,2,4,6,12,24,48}
c={1,4,8,10,12,15,18,20}
d={2,3,5,7,11,13,17,19,23,29,31,37}

def tryInt(txt:str):#metodo para leer datos enteros
    isTry=True
    while isTry:
        try:
            x=0
            x=int(input(txt))
        except:
            print("No es valido, ingrese nuevamente el dato")
            
        else:
            isTry=False
            return x


def union(a,b):
        unionC=set()

        for i in b:
 
            unionC.add(i)
        for i in a:

            unionC.add(i)
        
        return unionC

def interseccion(a,b):
    inter=set()

    for i in a:
        if i in b:
            inter.add(i)
    return inter

def dif(a,b):
    inter=set()

    for i in a:
        if not(i in b):

            inter.add(i)
    return inter

def simetrica(a,b):
    sim=set()

    union=set()

    for i in a:

        union.add(i)
    for i in b:

        union.add(i)
    
    inter=set()

    for i in a:
        if i in b:
            inter.add(i)
    
    for i in union:
        if not(i in inter):

            sim.add(i)
    return sim



# M={1,2,3,4}
# L={4,5,6,7}
a={6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29}
b={0,2,4,6,12,24,48}
c={2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44}
d={2,3,5,7,11,13,17,19,23,29,31,37}

bandera= 0
while bandera!=4:


    op=input("1.operacionA \n2.operacionB \n3.operacionC  \n4.salir\n:) ")
    if (op=="1"):
        
        dife=dif(a,c)
        int=interseccion(b,d)
        sim=simetrica(dife,int)
        print("Resultado: ")
        print(sim) 

    elif (op=="2"):
        
        int=interseccion(b,d)
        sim=simetrica(int,c)
        unionC=union(a,d)
        dife=dif(sim,unionC)
        print("Resultado: ")
        print(dife)  

    elif (op=="3"):
        
        inte=interseccion(a,c)
        inte=interseccion(inte,b)
        dife=dif(a,c)
        dife1=dif(b,d)
        unionC=union(dife,dife1)
        unionC1=union(inte,unionC)
        print("Resultado: ")
        print(unionC1)   

        
    elif (op=="4"):
        bandera=4
 

